#trgn510_assignment1

This directory contains my first assignment in Fall 2020 TRGN510


